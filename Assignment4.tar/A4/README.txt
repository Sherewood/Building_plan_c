101067032
Julien Rougerie
Within this file:
building.h
buildingPlan.c
buildingPlan.o
buildingTest
buildingTest.c
buildingTest.o
makefile
This readme 
TO RUN
-open terminal and run make
- afterwards, ./buildingTest should run the program

Notes:
-Recurssion might not work so hot.
